﻿using System;
using HimbeertoniRaidTool.Common.Data;
using Lumina.Excel;
using Lumina.Excel.CustomSheets;
using System.Collections.Generic;
using System.Linq;

namespace HimbeertoniRaidTool.Common.Services;

public class ItemInfo
{
    private readonly GameInfo _gameInfo;
    private readonly ExcelSheet<SpecialShop> _shopSheet;
    private readonly ExcelSheet<Lumina.Excel.GeneratedSheets.RecipeLookup> _recipeLookupSheet;
    private readonly Dictionary<uint, ItemIdCollection> _itemContainerDb;
    private readonly Dictionary<uint, List<(uint shopID, int idx)>> _shopIndex;
    private readonly Dictionary<uint, List<uint>> _usedAsCurrency;
    private readonly Dictionary<uint, List<uint>> _lootSources;

    internal ItemInfo(ExcelModule excelModule, CuratedData curData, GameInfo gameInfo)
    {
        _gameInfo = gameInfo;
        _itemContainerDb = curData.ItemContainerDb;
        _shopSheet = excelModule.GetSheet<SpecialShop>()!;
        _recipeLookupSheet = excelModule.GetSheet<Lumina.Excel.GeneratedSheets.RecipeLookup>()!;
        //Load Vendor Data
        _shopIndex = new Dictionary<uint, List<(uint shopID, int idx)>>();
        _usedAsCurrency = new Dictionary<uint, List<uint>>();
        foreach (SpecialShop shop in _shopSheet.Where(s => !string.IsNullOrEmpty(s.Name.RawString)))
            for (int idx = 0; idx < shop.ShopEntries.Length; idx++)
            {
                SpecialShop.ShopEntry entry = shop.ShopEntries[idx];
                foreach (SpecialShop.ItemReceiveEntry receiveEntry in entry.ItemReceiveEntries)
                {
                    if (receiveEntry.Item.Row == 0)
                        continue;
                    if (!_shopIndex.ContainsKey(receiveEntry.Item.Row))
                        _shopIndex[receiveEntry.Item.Row] = new List<(uint shopID, int idx)>();
                    if (_shopIndex[receiveEntry.Item.Row].Contains((shop.RowId, idx)))
                        continue;
                    _shopIndex[receiveEntry.Item.Row].Add((shop.RowId, idx));
                    foreach (SpecialShop.ItemCostEntry item in entry.ItemCostEntries)
                    {
                        if (item.Item.Row == 0) continue;
                        if (!_usedAsCurrency.ContainsKey(item.Item.Row))
                            _usedAsCurrency.Add(item.Item.Row, new List<uint>());
                        _usedAsCurrency[item.Item.Row].Add(entry.ItemReceiveEntries[0].Item.Row);
                    }
                }
            }

        _lootSources = new Dictionary<uint, List<uint>>();
        foreach (InstanceWithLoot instance in _gameInfo.GetInstances())
        foreach (HrtItem loot in instance.AllLoot)
        {
            RegisterLoot(loot.Id, instance.InstanceId);
            if (!IsItemContainer(loot.Id)) continue;
            foreach (HrtItem item in GetContainerContents(loot.Id).Select(id => new HrtItem(id)))
                RegisterLoot(item.Id, instance.InstanceId);
        }
    }

    private void RegisterLoot(uint itemId, uint instanceId)
    {
        if (!_lootSources.ContainsKey(itemId))
            _lootSources[itemId] = new List<uint>();
        if (!_lootSources[itemId].Contains(instanceId))
            _lootSources[itemId].Add(instanceId);
    }

    public bool CanBeLooted(uint itemId) => _lootSources.ContainsKey(itemId);

    public IEnumerable<InstanceWithLoot> GetLootSources(uint itemId)
    {
        if (_lootSources.TryGetValue(itemId, out var instanceIDs))
            foreach (uint instanceId in instanceIDs)
                yield return _gameInfo.GetInstance(instanceId);
    }

    public bool IsItemContainer(uint itemId) => _itemContainerDb.ContainsKey(itemId);

    public static bool IsCurrency(uint itemId) => Enum.IsDefined((Currency)itemId);

    public bool UsedAsShopCurrency(uint itemId) => _usedAsCurrency.ContainsKey(itemId);

    public bool CanBePurchased(uint itemId) => _shopIndex.ContainsKey(itemId);

    public bool CanBeCrafted(uint itemId) => _recipeLookupSheet.GetRow(itemId) != null;

    public ItemIdCollection GetPossiblePurchases(uint itemId) => new ItemIdList(_usedAsCurrency.GetValueOrDefault(itemId) ?? Enumerable.Empty<uint>());

    public ItemIdCollection GetContainerContents(uint itemId) => _itemContainerDb.GetValueOrDefault(itemId, ItemIdCollection.Empty);

    public IEnumerable<(string shopName, SpecialShop.ShopEntry entry)> GetShopEntriesForItem(uint itemId)
    {
        if (_shopIndex.TryGetValue(itemId, out var shopEntries))
            foreach ((uint shopId, int idx) in shopEntries)
            {
                SpecialShop? shop = _shopSheet.GetRow(shopId);
                if (shop != null)
                    yield return (shop.Name, shop.ShopEntries[idx]);
            }
    }

    public static bool IsTomeStone(uint itemId)
    {
        return itemId switch
        {
            23 => true,
            24 => true,
            26 => true,
            28 => true,
            >= 30 and <= 45 => true,
            _ => false,
        };
    }

    public ItemSource GetSource(HrtItem item, int maxDepth = 10)
    {
        uint itemId = item.Id;
        maxDepth--;
        if (itemId == 0)
            return ItemSource.Undefined;
        if (maxDepth < 0) return ItemSource.Undefined;
        if (item.Rarity == Rarity.Relic)
            return ItemSource.Relic;
        if (_lootSources.TryGetValue(itemId, out var instanceId))
            return _gameInfo.GetInstance(instanceId.First()).InstanceType.ToItemSource();
        if (CanBeCrafted(itemId))
            return ItemSource.Crafted;
        if (CanBePurchased(itemId))
        {
            if (GetShopEntriesForItem(itemId).Any(se => se.entry.ItemCostEntries.Any(e => CanBeCrafted(e.Item.Row)))
                || GetShopEntriesForItem(itemId).Any(se => se.entry.ItemCostEntries.Where(e => e.Item.Row != 0)
                    .Any(e => GetSource(new HrtItem(e.Item.Row), maxDepth) == ItemSource.Crafted)))
                return ItemSource.Crafted;
            if (GetShopEntriesForItem(itemId).Any(se => se.entry.ItemCostEntries.Any(e => IsTomeStone(e.Item.Row)))
                || GetShopEntriesForItem(itemId).Any(se => se.entry.ItemCostEntries.Where(e => e.Item.Row != 0)
                    .Any(e => GetSource(new HrtItem(e.Item.Row), maxDepth) == ItemSource.Tome)))
                return ItemSource.Tome;
            if (GetShopEntriesForItem(itemId).Any(se =>
                    se.entry.ItemCostEntries.Any(e => GetSource(new HrtItem(e.Item.Row), maxDepth) == ItemSource.Raid)))
                return ItemSource.Raid;
            return ItemSource.Shop;
        }

        return ItemSource.Undefined;
    }
}