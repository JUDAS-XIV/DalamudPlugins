﻿namespace NetStone.Definitions.Model;

/// <summary>
/// Interface for all node definitions
/// </summary>
public interface IDefinition
{
}