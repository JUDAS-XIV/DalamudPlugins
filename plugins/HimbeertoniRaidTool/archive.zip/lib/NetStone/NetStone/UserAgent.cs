﻿namespace NetStone;

internal enum UserAgent
{
    Desktop,
    Mobile,
}